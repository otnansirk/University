package com.example.flotting_button

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DiaryListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.diary_list)
    }
}