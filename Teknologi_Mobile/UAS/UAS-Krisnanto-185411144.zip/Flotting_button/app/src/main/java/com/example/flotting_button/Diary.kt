package com.example.flotting_button

class Diary(
    val title: String,
    val diary: String,
    val id: String
){
    constructor() : this("", "", "") {

    }
}