package com.example.diary_qu

class Diary(
    val title: String,
    val diary: String,
    val id: String
){
    constructor() : this("", "", "") {

    }
}