package com.example.diary_qu

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.flotting_button.R

class DiaryListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.diary_list)
    }
}